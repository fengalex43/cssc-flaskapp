Microsoft Azure CLI 'acrcssc' Extension
==========================================

This package is for the 'acrcssc' extension.
i.e. 'az acrcssc'

.. :changelog:

Release History
===============

0.1.0
++++++
* Initial release.

